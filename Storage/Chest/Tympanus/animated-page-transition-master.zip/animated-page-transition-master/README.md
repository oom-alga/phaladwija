Animated Page Transition
=========

A CSS powered animation, that replaces the refresh of the page while the content is updated using Ajax.

[Article on CodyHouse](http://codyhouse.co/gem/animated-page-transition/)

[Demo](http://codyhouse.co/demo/animated-page-transition/index.html)
 
[Terms](http://codyhouse.co/terms/)

import 'core-js/fn/map';
import 'core-js/fn/set';
import 'core-js/fn/weak-map';
import 'core-js/fn/array/from';
import 'core-js/fn/object/assign';

export enum TrackDirection {
  X = 'x',
  Y = 'y',
}
